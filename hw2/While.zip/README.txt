I used Python 3.7.4 for the code
And PyInstaller 3.6

Please install pyinstaller if you don't have it.
sudo pip install pyinstaller



--------------------------HW1----------------------------------------------
Followed these blog posts. Build AST and plug in the ARITH language. 
Added special treatment to '-' since it can be negative sign or minus 

https://ruslanspivak.com/lsbasi-part7/
https://rosettacode.org/wiki/Arithmetic_evaluation#Python

Used pyinstaller for makefile, learn how to write one from this website
https://github.com/operatorequals/covertutils/blob/master/makefile
Which is just some random git repo used pyinstaller




----------------HW2--------------------------
I hand build everything without looking at anything else